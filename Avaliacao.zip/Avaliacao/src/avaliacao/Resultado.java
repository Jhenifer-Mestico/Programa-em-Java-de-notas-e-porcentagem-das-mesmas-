package avaliacao;

import javax.swing.JOptionPane;

public class Resultado {
    
     public static void main(String[] args) {  //chamar 3 obj 
         Avaliacao objAvaliacao = new Avaliacao("PP1", "Prova Regimental (PR)", 8.5f);
         
         JOptionPane.showMessageDialog(null, objAvaliacao.toString() +  "\nPercentual = " + objAvaliacao.CalculoPercentual() + "%", "Avaliação:", JOptionPane.INFORMATION_MESSAGE);  
     }
}

package avaliacao;

public class Avaliacao {   //iniciar variavel

     private String nome, tipoavaliacao;  
     private float notamaxima, percentual; 

    public Avaliacao() {   //sem parametro
    }

    public Avaliacao(String nome, String tipoavaliacao, float notamaxima) {    //c parametro
        this.nome = nome;
        this.tipoavaliacao = tipoavaliacao;
        this.notamaxima = notamaxima;
    }
    
    public float CalculoPercentual(){    
        percentual = (notamaxima * 100) / 10;  
         return percentual;
    }

    @Override
    public String toString() {    //texto c to string
        return "Nome da Avaliação = " + nome + "\nTipo de Avaliação = " + tipoavaliacao + "\nNota Máxima = " + notamaxima;  
    }
      
    }